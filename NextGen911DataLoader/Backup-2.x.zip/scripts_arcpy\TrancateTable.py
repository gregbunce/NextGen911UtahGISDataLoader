﻿import arcpy
import sys
arcpy.TruncateTable_management(sys.argv[1])